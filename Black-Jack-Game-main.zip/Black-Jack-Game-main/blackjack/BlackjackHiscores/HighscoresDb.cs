using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;

public class HighScoresDb
{
    private string _connectionString;

    public HighScoresDb(string dbPath)
    {
        _connectionString = $"Data Source={dbPath}";

        if (!File.Exists(dbPath))
        {
            SQLiteConnection.CreateFile(dbPath);
            CreateTable();
            InsertInitialData();
        }
    }

    private void CreateTable()
    {
        using (var connection = new SQLiteConnection(_connectionString))
        {
            connection.Open();
            string createTableQuery = @"
                CREATE TABLE HighScores (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    PlayerName TEXT NOT NULL,
                    Score INTEGER NOT NULL
                )";
            using (var command = new SQLiteCommand(createTableQuery, connection))
            {
                command.ExecuteNonQuery();
            }
        }
    }

    public void InsertInitialData()
    {
        using (var connection = new SQLiteConnection(_connectionString))
        {
            connection.Open();
            string checkTableQuery = "SELECT COUNT(*) FROM HighScores";
            using (var command = new SQLiteCommand(checkTableQuery, connection))
            {
                long count = (long)command.ExecuteScalar();
                if (count == 0)
                {
                    var initialHighScores = new List<HighScore>
                    {
                        new HighScore { PlayerName = "Alice", Score = 150},
                        new HighScore { PlayerName = "Bob", Score = 120 },
                        new HighScore { PlayerName = "Charlie", Score = 100 }
                    };

                    foreach (var highScore in initialHighScores)
                    {
                        AddHighScore(highScore);
                    }
                }
            }
        }
    }

    public List<HighScore> GetHighScores()
    {
        var highScores = new List<HighScore>();
        using (var connection = new SQLiteConnection(_connectionString))
        {
            connection.Open();
            string selectQuery = "SELECT * FROM HighScores ORDER BY Score DESC";
            using (var command = new SQLiteCommand(selectQuery, connection))
            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    highScores.Add(new HighScore
                    {
                        Id = reader.GetInt32(0),
                        PlayerName = reader.GetString(1),
                        Score = reader.GetInt32(2)
                    });
                }
            }
        }
        return highScores;
    }

    public void AddHighScore(HighScore highScore)
    {
        using (var connection = new SQLiteConnection(_connectionString))
        {
            connection.Open();
            string insertQuery = "INSERT INTO HighScores (PlayerName, Score) VALUES (@PlayerName, @Score)";
            using (var command = new SQLiteCommand(insertQuery, connection))
            {
                command.Parameters.AddWithValue("@PlayerName", highScore.PlayerName);
                command.Parameters.AddWithValue("@Score", highScore.Score);
                command.ExecuteNonQuery();
            }
        }
    }
}

