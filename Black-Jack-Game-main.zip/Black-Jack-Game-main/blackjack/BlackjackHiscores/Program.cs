﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

class Program
{
    static HighScoresDb highScoresDb = new HighScoresDb("highscores.db");

    static async Task Main(string[] args)
    {
        var listener = new HttpListener();
        listener.Prefixes.Add("http://localhost:5000/");
        listener.Start();
        Console.WriteLine("Listening on http://localhost:5000/");

        while (true)
        {
            var context = await listener.GetContextAsync();
            var request = context.Request;
            var response = context.Response;

            // Add CORS headers
            response.Headers.Add("Access-Control-Allow-Origin", "*");
            response.Headers.Add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
            response.Headers.Add("Access-Control-Allow-Headers", "Content-Type");

            if (request.HttpMethod == "OPTIONS")
            {
                response.StatusCode = (int)HttpStatusCode.OK;
                response.Close();
                continue;
            }

            if (request.HttpMethod == "GET" && request.Url.AbsolutePath == "/api/HighScores")
            {
                var highScores = highScoresDb.GetHighScores();
                var json = JsonSerializer.Serialize(highScores);
                var buffer = Encoding.UTF8.GetBytes(json);
                response.ContentType = "application/json";
                response.ContentLength64 = buffer.Length;
                await response.OutputStream.WriteAsync(buffer, 0, buffer.Length);
                response.OutputStream.Close();
            }
            else if (request.HttpMethod == "POST" && request.Url.AbsolutePath == "/api/HighScores")
            {
                using (var reader = new System.IO.StreamReader(request.InputStream, request.ContentEncoding))
                {
                    var body = await reader.ReadToEndAsync();
                    var highScore = JsonSerializer.Deserialize<HighScore>(body);

                    if (string.IsNullOrEmpty(highScore.PlayerName))
                    {
                        response.StatusCode = (int)HttpStatusCode.BadRequest;
                        byte[] errorBuffer = Encoding.UTF8.GetBytes("PlayerName is required.");
                        await response.OutputStream.WriteAsync(errorBuffer, 0, errorBuffer.Length);
                        response.OutputStream.Close();
                        continue;
                    }

                    highScoresDb.AddHighScore(highScore);
                    response.StatusCode = (int)HttpStatusCode.Created;
                    response.Close();
                }
            }
            else
            {
                response.StatusCode = (int)HttpStatusCode.NotFound;
                response.Close();
            }
        }
    }
}